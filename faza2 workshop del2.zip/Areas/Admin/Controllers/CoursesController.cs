﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using UniversityMVC.Data;
using UniversityMVC.Models;

namespace UniversityMVC.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CoursesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CoursesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Admin/Courses?title=...&semester=...&programme=...
        public async Task<IActionResult> Index(string title, int? semester, string programme)
        {
            var query = _context.Courses
                .Include(c => c.FirstTeacher)
                .Include(c => c.SecondTeacher)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(title))
                query = query.Where(c => c.Title.Contains(title));

            if (semester.HasValue)
                query = query.Where(c => c.Semester == semester);

            if (!string.IsNullOrWhiteSpace(programme))
                query = query.Where(c => c.Programme.Contains(programme));

            return View(await query.ToListAsync());
        }

        // GET: /Admin/Courses/ByTeacher/5
        public async Task<IActionResult> ByTeacher(long id)
        {
            var courses = await _context.Courses
                .Include(c => c.FirstTeacher)
                .Include(c => c.SecondTeacher)
                .Where(c => c.FirstTeacherId == id || c.SecondTeacherId == id)
                .ToListAsync();

            ViewBag.TeacherId = id;
            return View(courses);
        }

        // GET: /Admin/Courses/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null) return NotFound();

            var course = await _context.Courses
                .Include(c => c.FirstTeacher)
                .Include(c => c.SecondTeacher)
                .Include(c => c.Enrollments)
                    .ThenInclude(e => e.Student)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (course == null) return NotFound();

            return View(course);
        }

        // GET: /Admin/Courses/Create
        public IActionResult Create()
        {
            ViewData["FirstTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName");
            ViewData["SecondTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName");
            return View();
        }

        // POST: /Admin/Courses/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Credits,Semester,Programme,EducationLevel,FirstTeacherId,SecondTeacherId")] Course course)
        {
            if (!ModelState.IsValid)
            {
                ViewData["FirstTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName", course.FirstTeacherId);
                ViewData["SecondTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName", course.SecondTeacherId);
                return View(course);
            }

            _context.Add(course);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: /Admin/Courses/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null) return NotFound();

            var course = await _context.Courses.FindAsync(id);
            if (course == null) return NotFound();

            ViewData["FirstTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName", course.FirstTeacherId);
            ViewData["SecondTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName", course.SecondTeacherId);
            return View(course);
        }

        // POST: /Admin/Courses/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("Id,Title,Credits,Semester,Programme,EducationLevel,FirstTeacherId,SecondTeacherId")] Course course)
        {
            if (id != course.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                ViewData["FirstTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName", course.FirstTeacherId);
                ViewData["SecondTeacherId"] = new SelectList(_context.Teachers, "Id", "LastName", course.SecondTeacherId);
                return View(course);
            }

            try
            {
                _context.Update(course);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(course.Id)) return NotFound();
                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: /Admin/Courses/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null) return NotFound();

            var course = await _context.Courses
                .Include(c => c.FirstTeacher)
                .Include(c => c.SecondTeacher)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (course == null) return NotFound();

            return View(course);
        }

        // POST: /Admin/Courses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course != null)
                _context.Courses.Remove(course);

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // ============================================================
        // ADMIN: ENROLL MANY STUDENTS FOR YEAR/SEMESTER (Фаза 2)
        // ============================================================

        // GET: /Admin/Courses/EnrollStudents/5
        [HttpGet]
        public async Task<IActionResult> EnrollStudents(long id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course == null) return NotFound();

            ViewBag.CourseId = id;
            ViewBag.CourseTitle = course.Title;
            ViewBag.Students = await _context.Students.OrderBy(s => s.StudentId).ToListAsync();
            return View();
        }

        // POST: /Admin/Courses/EnrollStudents
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EnrollStudents(long courseId, int year, string semester, List<long> studentIds)
        {
            if (studentIds == null || studentIds.Count == 0)
                return RedirectToAction(nameof(Details), new { id = courseId });

            // спречи дупликати за ист course/year/semester
            var existing = await _context.Enrollments
                .Where(e => e.CourseId == courseId && e.Year == year && e.Semester == semester)
                .Select(e => e.StudentId)
                .ToListAsync();

            foreach (var sid in studentIds.Distinct())
            {
                if (existing.Contains(sid)) continue;

                _context.Enrollments.Add(new Enrollment
                {
                    CourseId = courseId,
                    StudentId = sid,
                    Year = year,
                    Semester = semester,
                    // останатите полиња остануваат null
                });
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id = courseId });
        }

        // ============================================================
        // ADMIN: DEACTIVATE / UNENROLL MANY STUDENTS (FinishDate) (Фаза 2)
        // ============================================================

        // GET: /Admin/Courses/DeactivateStudents?courseId=1&year=2025&semester=Winter
        public async Task<IActionResult> DeactivateStudents(long courseId, int? year, string? semester)
        {
            var course = await _context.Courses.FirstOrDefaultAsync(c => c.Id == courseId);
            if (course == null) return NotFound();

            // години што постојат за предметот
            var years = await _context.Enrollments
                .Where(e => e.CourseId == courseId && e.Year != null)
                .Select(e => e.Year!.Value)
                .Distinct()
                .OrderByDescending(y => y)
                .ToListAsync();

            // ако не е дадена година, земи најнова
            int? selectedYear = year ?? (years.Count > 0 ? years[0] : (int?)null);

            // ✅ FIX: query мора да е IQueryable<Enrollment> (не IIncludableQueryable)
            IQueryable<Enrollment> query = _context.Enrollments
                .Where(e => e.CourseId == courseId);

            if (selectedYear != null)
                query = query.Where(e => e.Year == selectedYear);

            if (!string.IsNullOrEmpty(semester))
                query = query.Where(e => e.Semester == semester);

            // прикажи само активни (FinishDate == null)
            var activeEnrollments = await query
                .Include(e => e.Student)
                .Where(e => e.FinishDate == null)
                .OrderBy(e => e.Student!.StudentId)
                .ToListAsync();

            ViewBag.Course = course;
            ViewBag.Years = years;
            ViewBag.SelectedYear = selectedYear;
            ViewBag.Semester = semester;

            return View(activeEnrollments);
        }

        // POST: /Admin/Courses/DeactivateStudents
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeactivateStudents(long courseId, int? year, string? semester, DateTime finishDate, List<long> enrollmentIds)
        {
            if (enrollmentIds == null || enrollmentIds.Count == 0)
                return RedirectToAction(nameof(DeactivateStudents), new { courseId, year, semester });

            var enrollments = await _context.Enrollments
                .Where(e => enrollmentIds.Contains(e.Id))
                .ToListAsync();

            foreach (var e in enrollments)
                e.FinishDate = finishDate;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(DeactivateStudents), new { courseId, year, semester });
        }

        private bool CourseExists(long id) => _context.Courses.Any(e => e.Id == id);
    }
}


