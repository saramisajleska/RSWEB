﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityMVC.Data;

namespace UniversityMVC.Areas.Student.Controllers
{
    [Area("Student")]
    public class EnrollmentsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;

        public EnrollmentsController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET: /Student/Enrollments/MyEnrollments?studentId=1
        public async Task<IActionResult> MyEnrollments(long studentId)
        {
            var enrollments = await _context.Enrollments
                .Where(e => e.StudentId == studentId)
                .Include(e => e.Course)
                .OrderByDescending(e => e.Year)
                .ThenBy(e => e.Course!.Title)
                .ToListAsync();

            ViewBag.StudentId = studentId;
            return View(enrollments);
        }

        // GET: /Student/Enrollments/EditUrls?enrollmentId=10&studentId=1
        public async Task<IActionResult> EditUrls(long enrollmentId, long studentId)
        {
            var enrollment = await _context.Enrollments
                .Include(e => e.Course)
                .FirstOrDefaultAsync(e => e.Id == enrollmentId);

            if (enrollment == null) return NotFound();
            if (enrollment.StudentId != studentId) return Forbid();

            ViewBag.StudentId = studentId;
            return View(enrollment);
        }

        // POST: /Student/Enrollments/EditUrls
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUrls(long id, long studentId, string? SeminarUrl, string? ProjectUrl)
        {
            var enrollment = await _context.Enrollments.FirstOrDefaultAsync(e => e.Id == id);

            if (enrollment == null) return NotFound();
            if (enrollment.StudentId != studentId) return Forbid();

            // студентот смее да менува САМО URL полиња
            enrollment.SeminarUrl = SeminarUrl;
            enrollment.ProjectUrl = ProjectUrl;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(MyEnrollments), new { studentId });
        }

        // POST: /Student/Enrollments/UploadSeminar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadSeminar(long enrollmentId, long studentId, IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("Нема прикачено датотека.");

            var enrollment = await _context.Enrollments.FirstOrDefaultAsync(e => e.Id == enrollmentId);

            if (enrollment == null) return NotFound();
            if (enrollment.StudentId != studentId) return Forbid();

            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            var allowed = new[] { ".doc", ".docx", ".pdf" };
            if (!allowed.Contains(ext))
                return BadRequest("Дозволени формати: doc, docx, pdf.");

            var uploadsFolder = Path.Combine(_env.WebRootPath, "uploads");
            Directory.CreateDirectory(uploadsFolder);

            var safeFileName = $"{Guid.NewGuid():N}_{Path.GetFileName(file.FileName)}";
            var fullPath = Path.Combine(uploadsFolder, safeFileName);

            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            // запиши path во SeminarUrl
            enrollment.SeminarUrl = "/uploads/" + safeFileName;
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(EditUrls), new { enrollmentId, studentId });
        }
    }
}
