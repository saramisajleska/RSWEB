﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityMVC.Data;
using UniversityMVC.Models;

namespace UniversityMVC.Areas.Professor.Controllers
{
    [Area("Professor")]
    public class CoursesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CoursesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Professor/Courses/MyCourses?teacherId=1
        public async Task<IActionResult> MyCourses(long teacherId)
        {
            var courses = await _context.Courses
                .Where(c => c.FirstTeacherId == teacherId || c.SecondTeacherId == teacherId)
                .OrderBy(c => c.Title)
                .ToListAsync();

            ViewBag.TeacherId = teacherId;
            return View(courses);
        }

        // GET: /Professor/Courses/Students?courseId=1&teacherId=1&year=2025
        public async Task<IActionResult> Students(long courseId, long teacherId, int? year)
        {
            var course = await _context.Courses.FirstOrDefaultAsync(c => c.Id == courseId);
            if (course == null) return NotFound();

            // професорот мора да го предава предметот
            var teaches = course.FirstTeacherId == teacherId || course.SecondTeacherId == teacherId;
            if (!teaches) return Forbid();

            // години што постојат за предметот
            var years = await _context.Enrollments
                .Where(e => e.CourseId == courseId && e.Year != null)
                .Select(e => e.Year!.Value)
                .Distinct()
                .OrderByDescending(y => y)
                .ToListAsync();

            int? selectedYear = year;
            if (selectedYear == null && years.Count > 0)
                selectedYear = years[0]; // најнова

            var enrollmentsQuery = _context.Enrollments
                .Where(e => e.CourseId == courseId);

            if (selectedYear != null)
                enrollmentsQuery = enrollmentsQuery.Where(e => e.Year == selectedYear);

            var enrollments = await enrollmentsQuery
                .Include(e => e.Student)
                .OrderBy(e => e.Student!.StudentId) // кај тебе е StudentId string
                .ToListAsync();

            ViewBag.Course = course;
            ViewBag.TeacherId = teacherId;
            ViewBag.Years = years;
            ViewBag.SelectedYear = selectedYear;

            return View(enrollments);
        }

        // GET: /Professor/Courses/EditEnrollment?enrollmentId=10&teacherId=1
        public async Task<IActionResult> EditEnrollment(long enrollmentId, long teacherId)
        {
            var enrollment = await _context.Enrollments
                .Include(e => e.Course)
                .Include(e => e.Student)
                .FirstOrDefaultAsync(e => e.Id == enrollmentId);

            if (enrollment == null) return NotFound();

            var teaches = (enrollment.Course?.FirstTeacherId == teacherId) || (enrollment.Course?.SecondTeacherId == teacherId);
            if (!teaches) return Forbid();

            ViewBag.TeacherId = teacherId;
            return View(enrollment);
        }

        // POST: /Professor/Courses/EditEnrollment
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEnrollment(
            long id,
            long teacherId,
            int? ExamPoints,
            int? SeminarPoints,
            int? ProjectPoints,
            int? AdditionalPoints,
            int? Grade,
            DateTime? FinishDate)
        {
            var enrollment = await _context.Enrollments
                .Include(e => e.Course)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (enrollment == null) return NotFound();

            var teaches = (enrollment.Course?.FirstTeacherId == teacherId) || (enrollment.Course?.SecondTeacherId == teacherId);
            if (!teaches) return Forbid();

            // активен студент = нема FinishDate
            if (enrollment.FinishDate != null)
                return BadRequest("Не може да се менува неактивен enrollment (веќе има FinishDate).");

            // професорот смее да менува само овие полиња
            enrollment.ExamPoints = ExamPoints;
            enrollment.SeminarPoints = SeminarPoints;
            enrollment.ProjectPoints = ProjectPoints;
            enrollment.AdditionalPoints = AdditionalPoints;
            enrollment.Grade = Grade;
            enrollment.FinishDate = FinishDate;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Students), new
            {
                courseId = enrollment.CourseId,
                teacherId = teacherId,
                year = enrollment.Year
            });
        }
    }
}
