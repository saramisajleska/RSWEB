﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace UniversityMVC.Models
{
    public class Teacher
    {
        public int Id { get; set; }

        [Required, StringLength(50)]
        public string FirstName { get; set; }

        [Required, StringLength(50)]
        public string LastName { get; set; }

        [StringLength(50)]
        public string? Degree { get; set; }

        [StringLength(50)]
        public string? AcademicRank { get; set; }

        [StringLength(20)]
        public string? OfficeNumber { get; set; }

        public DateTime? HireDate { get; set; }
        public string? PhotoPath { get; set; }

        public ICollection<Course> FirstTeacherCourses { get; set; } = new List<Course>();
        public ICollection<Course> SecondTeacherCourses { get; set; } = new List<Course>();
    }
}

