﻿using System;

namespace UniversityMVC.Models
{
    public class Enrollment
    {
        public long Id { get; set; }

        public int CourseId { get; set; }
        public Course Course { get; set; }

        public long StudentId { get; set; }
        public Student Student { get; set; }

        public int? Semester { get; set; }
        public int? Year { get; set; }
        public int? Grade { get; set; }

        public string? SeminarUrl { get; set; }
        public string? ProjectUrl { get; set; }

        public int? ExamPoints { get; set; }
        public int? SeminarPoints { get; set; }
        public int? ProjectPoints { get; set; }
        public int? AdditionalPoints { get; set; }

        public DateTime? FinishDate { get; set; }
    }
}
